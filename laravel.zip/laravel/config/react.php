<?php

return [
  'source'     => public_path('vendor/react-laravel/react.js'),
  'dom-source' => public_path('vendor/react-laravel/react-dom.js'),
  'dom-server-source' => public_path('vendor/react-laravel/react-dom-server.js'),
  'components' => public_path('js/components.js')
];
