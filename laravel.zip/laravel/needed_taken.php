<?php
class cneeded {
	public $name="";
	public $number="";
			
	function __construct($name,$number){
		$this->number=$number;
		$this->name=$name;
	}
}


class ctaken {
	public $name="";
	public $number="";
			
	function __construct($name,$number){
		$this->number=$number;
		$this->name=$name;
	}
}

?>